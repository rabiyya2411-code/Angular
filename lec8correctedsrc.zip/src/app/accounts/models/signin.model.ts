export class SignInModel {
  constructor(
    public email: String = '',
    public password: String = ''
  ) {}
}
